#ifndef _CODECB_
#define _CODECB_

void enB(char** dcode);

void deB(char** dcode);

#endif