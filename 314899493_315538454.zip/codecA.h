#ifndef _CODECA_
#define _CODECA_

void convert_letters(char** astring);

#endif